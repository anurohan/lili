import json, os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "backend", "data")

def load_json(filename):
    with open(os.path.join(DATA_DIR, filename), "r", encoding="utf-8") as f:
        return json.load(f)

DAILY = load_json("lili_daily.json")
EMOTION = load_json("lili_emotion.json")
STUDY = load_json("lili_study.json")

ALL_DATA = {**DAILY, **EMOTION, **STUDY}

@app.post("/chat")
def chat(req: ChatRequest):
    msg = req.message.lower()
    for key, reply in ALL_DATA.items():
        if key in msg:
            return {"reply": reply}
    return {"reply": "Hmm 🤔 samajh nahi aaya, thoda aur batao na 💖"}
